library(xgboost)    #make sure you have install.packages('xgboost')
library(openxlsx)   #make sure you have install.packages('openxlsx')
r2<-list()
#load the trained XGboost model
load("D:/trained_global_XGBoost_daily_ea.RData")  #please modify the file path.
  
#load the test xlsx file, please modify the file path
  test<-read.xlsx("D:/test/53336.xlsx",colNames = FALSE) #The three columns of input data are Tmax Tmin and AI. 
  test[,4]<-(test[,1]+test[,2])/2    #claculated the mean temperature
  names(test)<-c('Tmax','Tmin','AI','Tave')
  
  testX<-as.matrix(cbind(test$Tave,test$Tmin,test$AI)); #input data
  pred_monthly_ea<-predict(reg.rf, testX)  #pridict monthly ea
  
  pred_monthly_ea<-as.matrix(pred_monthly_ea);
  r2<-cbind(test,pred_monthly_ea)
  write.csv(r2,file=paste("D:/","Predict_ea_daily.csv",sep=""), row.names = F); #save the data, please modify the file path.
